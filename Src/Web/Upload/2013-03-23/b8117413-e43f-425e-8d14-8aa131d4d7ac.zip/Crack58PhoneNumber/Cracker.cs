﻿using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;

namespace Crack58PhoneNumber
{
    public class Cracker
    {
        List<Table> _words = new List<Table>();
        WebClient _wc = new WebClient();

        public Cracker()
        {
            for (int k = 0; k < 10; k++)
            {
                var ch = k.ToString()[0];
                _words.Add(new Table((Bitmap)Image.FromFile(@"C:\Users\Aimeast\Desktop\images\Specimen\" + k + "a.png"), ch));
                _words.Add(new Table((Bitmap)Image.FromFile(@"C:\Users\Aimeast\Desktop\images\Specimen\" + k + "b.png"), ch));
            }
        }

        public string Read(string url, int count = 5)
        {
            return Enumerable.Repeat(url, count)
                .Select(s => Read((Bitmap)Image.FromStream(new MemoryStream(_wc.DownloadData(s)))))
                .Where(s => s.Length == 11)
                .GroupBy(s => s)
                .OrderByDescending(s => s.Count())
                .First()
                .Key;
        }

        public string Read(Bitmap bmp)
        {
            var table = new Table(bmp);
            var bottom = FindBottom(table);
            var left = 1;
            var result = string.Empty;

            while (left < table.Width - 6)
            {
                var current = _words
                    .Where(s => left + s.Width < table.Width)
                    .Select(target =>
                    {
                        var total = 0.0;
                        var count = 0.0;
                        for (int i = 0; i < target.Width; i++)
                            for (int j = 0; j < target.Height; j++)
                                if (target[i, j])
                                {
                                    total++;
                                    if (table[left + i, bottom - target.Height + j])
                                        count++;
                                    else
                                        count--;
                                }
                                else if (table[left + i, bottom - target.Height + j])
                                    count -= 0.55;
                        return new { Rate = count / total, Table = target };
                    })
                    .Where(s => s.Rate > 0.5)
                    .OrderByDescending(s => s.Rate)
                    .FirstOrDefault();
                if (current != null)
                {
                    result += current.Table.Char;
                    left += current.Table.Width - 3;
                }
                else
                {
                    left++;
                }
            }

            return result;
        }

        private int FindBottom(Table table)
        {
            for (int j = table.Height - 1; j > 0; j--)
            {
                for (int i = 0; i < table.Width; i++)
                    if (table[i, j])
                        return j + 1;
            }
            return -1;
        }

        private class Table
        {
            private bool[,] _table;

            public Table(Bitmap bmp, char? ch = null)
            {
                Char = ch;
                Width = bmp.Width;
                Height = bmp.Height;

                var table = new bool[bmp.Width, bmp.Height];
                for (int i = 0; i < bmp.Width; i++)
                    for (int j = 0; j < bmp.Height; j++)
                    {
                        var px = bmp.GetPixel(i, j);
                        if (px.R + px.G + px.B < 700)
                            table[i, j] = true;
                    }
                _table = table;
            }

            public char? Char { get; private set; }
            public int Width { get; private set; }
            public int Height { get; private set; }

            public bool this[int x, int y]
            {
                get { return _table[x, y]; }
                set { _table[x, y] = value; }
            }
        }
    }
}
