﻿using System.Drawing;
using System.Drawing.Imaging;
using System.Net;

namespace Crack58PhoneNumber
{
    public static class Prapare
    {
        public static void GetImages()
        {
            var wc = new WebClient();
            for (int i = 0; i < 20; i++)
                wc.DownloadFile("http://image.58.com/showphone.aspx?t=v55&v=760DAE9D6C37AE54X1954E879A118A461", "G" + i + ".jpg");
        }

        public static void Binarization()
        {
            for (int k = 0; k < 10; k++)
            {
                var img = (Bitmap)Image.FromFile(@"C:\Users\Aimeast\Desktop\images\Specimen\" + k + "a.png");

                InternalBinarization(img).Save(@"C:\Users\Aimeast\Desktop\images\Specimen\" + k + "b.png", ImageFormat.Png);
                InternalBinarization(new Bitmap(img, img.Width * 16 / 17, 16)).Save(@"C:\Users\Aimeast\Desktop\images\Specimen\" + k + "c.png", ImageFormat.Png);
                //InternalBinarization(new Bitmap(img, img.Width * 15 / 17, 15)).Save(@"C:\Users\Aimeast\Desktop\images\Specimen\" + k + "d.png", ImageFormat.Png);
                //InternalBinarization(new Bitmap(img, img.Width * 14 / 17, 14)).Save(@"C:\Users\Aimeast\Desktop\images\Specimen\" + k + "e.png", ImageFormat.Png);
            }
        }

        public static Bitmap InternalBinarization(Bitmap org)
        {
            var bmp = new Bitmap(org.Width, org.Height);
            for (int i = 0; i < org.Width; i++)
                for (int j = 0; j < org.Height; j++)
                {
                    var px = org.GetPixel(i, j);
                    if (px.R + px.G + px.B < 700)
                        bmp.SetPixel(i, j, Color.Black);
                }
            return bmp;
        }
    }
}
