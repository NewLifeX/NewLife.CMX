﻿using System.Drawing;
using System.IO;
using System.Linq;

namespace Crack58PhoneNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            var cracker = new Cracker();
            var result = cracker.Read(@"http://image.58.com/showphone.aspx?t=v55&v=760DAE9D6C37AE54X1954E879A118A461");

            var list = Directory.GetFiles(@"C:\Users\Aimeast\Desktop\images\Samples\", "*.jpg")
                .Select(s => cracker.Read((Bitmap)Image.FromFile(s)))
                .ToList();
        }
    }
}
